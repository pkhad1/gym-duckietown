# helps with some package managers to install the jsons
