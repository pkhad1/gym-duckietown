# coding=utf-8
DEFAULTS = {
    "map": "small_loop",
    "domain_rand": False,
    "max_steps": 500,
    "challenges": {"LF": "loop_obstacles", "LFV": "loop_pedestrians"},
}
